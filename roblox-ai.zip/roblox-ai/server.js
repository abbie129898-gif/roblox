// Máy chủ nhỏ, không cần cài thư viện. Cần Node.js 18 trở lên.
// Tự đọc file .env (nếu có) để chạy được cả trên máy lẫn trên dịch vụ hosting.
try { for (const l of require('fs').readFileSync(require('path').join(__dirname, '.env'), 'utf8').split(/\r?\n/)) { const m = /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(l); if (m && !l.trim().startsWith('#') && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, ''); } } catch {}
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const KEY = process.env.OPENAI_API_KEY, CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const MODEL = process.env.OPENAI_MODEL || 'chat-latest', PORT = process.env.PORT || 3000;
const LIMIT = +process.env.DAILY_LIMIT || 30;            // lượt hỏi / tài khoản / ngày
const IP_LIMIT = +process.env.IP_DAILY_LIMIT || 100;     // trần lượt theo IP, chống tạo nhiều tài khoản
const TRUST_PROXY = process.env.TRUST_PROXY === '1';     // bật khi chạy sau Render/Railway/Nginx
const ADMIN = (process.env.ADMIN_EMAIL || 'abbie129898@gmail.com').trim().toLowerCase();
const DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
if (!KEY || !CLIENT_ID) { console.error('Thiếu OPENAI_API_KEY hoặc GOOGLE_CLIENT_ID. Xem README.md'); process.exit(1); }

const SYS = `Bạn là trợ lý chuyên viết script Roblox bằng Luau.
- Trả lời bằng ngôn ngữ người dùng đang dùng (mặc định tiếng Việt). Giải thích ngắn gọn, dễ hiểu cho người mới.
- Đặt code trong khối \`\`\`lua. Với mỗi script, nói rõ loại (Script, LocalScript hay ModuleScript) và đặt ở đâu (ServerScriptService, StarterPlayerScripts, ReplicatedStorage, StarterGui...).
- Dùng API hiện đại: task.wait thay cho wait, task.spawn, :GetService, DataStoreService có pcall.
- Bảo mật: không tin dữ liệu từ client. Kiểm tra lại trên server khi dùng RemoteEvent/RemoteFunction.
- Khi người dùng gửi script lỗi, chỉ ra nguyên nhân rồi đưa bản đã sửa.
- Chỉ viết script chạy trong Roblox Studio cho game của chính người dùng. Không viết script cho trình thực thi/executor (như Delta, Fluxus...), không viết exploit, hack, cheat hay script can thiệp vào game của người khác, và không giúp vượt qua điều khoản của Roblox. Từ chối ngắn gọn và đề xuất cách hợp lệ để đạt mục tiêu (ví dụ làm tính năng tương tự trong game của chính họ).`;

// ---- Lưu trữ (file JSON) ----
const dayKey = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Ho_Chi_Minh' }); // đổi ngày 00:00 giờ VN
const resetAt = day => { const [y, m, d] = day.split('-').map(Number); return Date.UTC(y, m - 1, d + 1) - 7 * 36e5; };
const load = (f, d) => { try { return JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8')); } catch { return d; } };
const timers = {};
const save = (f, get) => { clearTimeout(timers[f]); timers[f] = setTimeout(() => fs.mkdir(DIR, { recursive: true }, () => fs.writeFile(path.join(DIR, f), JSON.stringify(get()), () => {})), 1200); };
let db = load('db.json', { users: {}, sessions: {}, bans: {} });
let usage = load('usage.json', { day: dayKey(), n: {} });
if (usage.day !== dayKey()) usage = { day: dayKey(), n: {} };
const saveDb = () => save('db.json', () => db), saveUse = () => save('usage.json', () => usage);
const roll = () => { const d = dayKey(); if (usage.day !== d) { usage = { day: d, n: {} }; saveUse(); } };
const used = k => usage.n[k] || 0;
const sha = s => crypto.createHash('sha256').update(s).digest('hex');

// ---- Phiên đăng nhập ----
const cookie = (req, n) => { const m = new RegExp('(?:^|; )' + n + '=([a-f0-9]+)').exec(req.headers.cookie || ''); return m && m[1]; };
function who(req) { const t = cookie(req, 'rbx_sess'); if (!t) return null; const s = db.sessions[sha(t)]; return s && s.exp > Date.now() ? db.users[s.email] || null : null; }
const secure = req => req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
function startSession(req, res, email) {
  const t = crypto.randomBytes(32).toString('hex');
  db.sessions[sha(t)] = { email, exp: Date.now() + 30 * 864e5 }; saveDb();
  res.setHeader('Set-Cookie', 'rbx_sess=' + t + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=' + 30 * 86400 + secure(req));
}
const pub = u => ({ email: u.email, name: u.name, picture: u.picture, isAdmin: u.email === ADMIN });
const quota = u => { const d = Math.max(0, LIMIT - used('u:' + u.email)); return { limit: LIMIT, daily: d, extra: u.extra || 0, remaining: d + (u.extra || 0), resetAt: resetAt(usage.day) }; };

async function verifyGoogle(cred) {
  const r = await fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(cred), { signal: AbortSignal.timeout(10000) });
  if (!r.ok) return null;
  const t = await r.json(), ver = t.email_verified === true || t.email_verified === 'true';
  const okIss = t.iss === 'accounts.google.com' || t.iss === 'https://accounts.google.com';
  return t.aud === CLIENT_ID && okIss && ver && t.email && +t.exp * 1000 > Date.now() ? t : null;
}

const rl = {};
function limited(kind, ip, max) { const m = rl[kind] || (rl[kind] = new Map()), n = Date.now(), a = (m.get(ip) || []).filter(t => n - t < 6e5); a.push(n); m.set(ip, a); return a.length > max; }
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(obj)); };
async function readJson(req) { let b = ''; for await (const c of req) { b += c; if (b.length > 65536) throw new Error('big'); } return b ? JSON.parse(b) : {}; }

async function handle(req, res) {
  let ip = (TRUST_PROXY && (req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || '';
  ip = ip.replace(/^::ffff:/, '');
  const u = who(req), isAdmin = !!u && u.email === ADMIN, url = req.url.split('?')[0];

  if (db.bans[ip] && !isAdmin) {   // IP bị chặn: chặn mọi thứ (admin thì không bị chặn)
    if (req.method === 'GET' && !url.startsWith('/api/')) { res.writeHead(403, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end('<meta charset="utf-8"><title>Bị chặn</title><p style="font:16px system-ui;padding:24px">Địa chỉ IP của bạn đã bị quản trị viên chặn khỏi trang này.</p>'); }
    return send(res, 403, { error: 'Địa chỉ IP của bạn đã bị chặn.' });
  }
  if (req.method === 'GET' && (url === '/' || url === '/index.html')) { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return fs.createReadStream(path.join(__dirname, 'public', 'index.html')).pipe(res); }
  if (req.method === 'GET' && url === '/api/config') return send(res, 200, { clientId: CLIENT_ID, limit: LIMIT });
  if (req.method === 'GET' && url === '/api/me') { roll(); return send(res, 200, u ? { user: pub(u), quota: quota(u) } : { user: null }); }

  let body = {};
  if (req.method === 'POST') {
    if (!/^application\/json/i.test(req.headers['content-type'] || '')) return send(res, 415, { error: 'Sai kiểu dữ liệu.' });
    try { body = await readJson(req); } catch { return send(res, 400, { error: 'Dữ liệu không hợp lệ.' }); }
  }

  if (req.method === 'POST' && url === '/api/auth/google') {
    if (limited('auth', ip, 30)) return send(res, 429, { error: 'Thử đăng nhập quá nhiều lần, hãy đợi vài phút.' });
    const t = typeof body.credential === 'string' ? await verifyGoogle(body.credential).catch(() => null) : null;
    if (!t) return send(res, 401, { error: 'Không xác thực được tài khoản Google. Hãy thử lại.' });
    const email = t.email.toLowerCase();
    if (body.admin && email !== ADMIN) return send(res, 403, { error: 'Tài khoản này không có quyền admin.' });
    const now = Date.now(), x = db.users[email] || (db.users[email] = { email, createdAt: now, extra: 0, chats: 0, ips: [] });
    x.name = t.name || email; x.picture = t.picture || ''; x.lastLogin = now; x.lastIp = ip;
    if (!x.ips.includes(ip)) x.ips = [...x.ips, ip].slice(-5);
    saveDb(); startSession(req, res, email); roll();
    return send(res, 200, { user: pub(x), quota: quota(x) });
  }
  if (req.method === 'POST' && url === '/api/auth/logout') {
    const t = cookie(req, 'rbx_sess'); if (t) { delete db.sessions[sha(t)]; saveDb(); }
    res.setHeader('Set-Cookie', 'rbx_sess=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0' + secure(req));
    return send(res, 200, { ok: true });
  }

  // ---- Khu vực admin: luôn kiểm tra quyền ở máy chủ ----
  if (url.startsWith('/api/admin/')) {
    if (!isAdmin) return send(res, 403, { error: 'Không có quyền admin.' });
    roll();
    if (req.method === 'GET' && url === '/api/admin/data') {
      const users = Object.values(db.users).sort((a, b) => b.createdAt - a.createdAt).map(x => ({
        email: x.email, name: x.name, picture: x.picture, createdAt: x.createdAt, lastLogin: x.lastLogin, lastIp: x.lastIp,
        extra: x.extra || 0, chats: x.chats || 0, usedToday: used('u:' + x.email), banned: !!db.bans[x.lastIp] }));
      const bans = Object.entries(db.bans).map(([i, b]) => ({ ip: i, at: b.at, note: b.note }));
      return send(res, 200, { limit: LIMIT, users, bans, you: ip });
    }
    if (req.method === 'POST' && url === '/api/admin/quota') {
      const x = db.users[String(body.email || '').toLowerCase()], n = Math.trunc(+body.add);
      if (!x || !Number.isFinite(n) || Math.abs(n) > 1000) return send(res, 400, { error: 'Email hoặc số lượt không hợp lệ (tối đa ±1000).' });
      x.extra = Math.max(0, (x.extra || 0) + n); saveDb();
      return send(res, 200, { email: x.email, extra: x.extra });
    }
    if (req.method === 'POST' && url === '/api/admin/ban') {
      const t = String(body.ip || '').trim();
      if (!/^[0-9a-fA-F:.]{3,45}$/.test(t)) return send(res, 400, { error: 'Địa chỉ IP không hợp lệ.' });
      const mine = new Set([ip, ...((db.users[ADMIN] || {}).ips || [])]);
      if (mine.has(t)) return send(res, 400, { error: 'Không thể chặn IP mà chính bạn đang hoặc đã dùng.' });
      db.bans[t] = { at: Date.now(), note: String(body.note || '').slice(0, 100) }; saveDb();
      return send(res, 200, { ok: true });
    }
    if (req.method === 'POST' && url === '/api/admin/unban') { delete db.bans[String(body.ip || '')]; saveDb(); return send(res, 200, { ok: true }); }
    return send(res, 404, { error: 'Không tìm thấy.' });
  }

  if (req.method === 'POST' && url === '/api/chat') {
    if (!u) return send(res, 401, { error: 'Bạn cần đăng nhập để hỏi.', needLogin: true });
    roll();
    const k = 'u:' + u.email;
    const can = () => (used(k) < LIMIT && used('i:' + ip) < IP_LIMIT) || (u.extra || 0) > 0;
    const tooMany = () => send(res, 429, { error: 'Bạn đã dùng hết lượt hỏi hôm nay. Hãy quay lại vào ngày mai nhé!', quota: quota(u) });
    if (!can()) return tooMany();
    if (limited('chat', ip, 20)) return send(res, 429, { error: 'Bạn gửi hơi nhanh, hãy thử lại sau vài phút.' });
    let msgs = body.messages;
    if (!Array.isArray(msgs)) return send(res, 400, { error: 'Dữ liệu không hợp lệ.' });
    msgs = msgs.slice(-16).filter(m => m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string').map(m => ({ role: m.role, content: m.content.slice(0, 6000) }));
    if (!msgs.length) return send(res, 400, { error: 'Chưa có nội dung.' });

    roll(); if (!can()) return tooMany();        // kiểm tra lại, phòng gửi nhiều yêu cầu cùng lúc
    const day = usage.day; let viaExtra = false;  // giữ chỗ 1 lượt: dùng lượt ngày trước, hết mới trừ lượt tặng
    if (used(k) < LIMIT && used('i:' + ip) < IP_LIMIT) { usage.n[k] = used(k) + 1; usage.n['i:' + ip] = used('i:' + ip) + 1; saveUse(); }
    else { u.extra -= 1; viaExtra = true; saveDb(); }
    const refund = () => {
      if (viaExtra) { u.extra += 1; saveDb(); }
      else if (usage.day === day) { usage.n[k] = Math.max(0, used(k) - 1); usage.n['i:' + ip] = Math.max(0, used('i:' + ip) - 1); saveUse(); }
    };
    try {
      const r = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + KEY },
        body: JSON.stringify({ model: MODEL, messages: [{ role: 'system', content: SYS }, ...msgs] }), signal: AbortSignal.timeout(90000) });
      const d = await r.json();
      if (!r.ok) { refund(); console.error('OpenAI lỗi', r.status, d.error); return send(res, 502, { error: 'OpenAI báo lỗi (mã ' + r.status + '). Lượt hỏi này không bị tính. Chủ trang hãy xem log máy chủ.', quota: quota(u) }); }
      u.chats = (u.chats || 0) + 1; saveDb();
      return send(res, 200, { reply: d.choices[0].message.content, quota: quota(u) });
    } catch (e) { refund(); console.error(e); return send(res, 502, { error: 'Không kết nối được tới OpenAI. Lượt hỏi này không bị tính.', quota: quota(u) }); }
  }
  send(res, 404, { error: 'Không tìm thấy.' });
}
http.createServer((req, res) => handle(req, res).catch(e => { console.error(e); if (!res.headersSent) send(res, 500, { error: 'Lỗi máy chủ.' }); }))
  .listen(PORT, () => console.log('Đang chạy tại http://localhost:' + PORT + ' | admin: ' + ADMIN + ' | ' + LIMIT + ' lượt/ngày'));
