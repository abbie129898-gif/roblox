# Trợ lý script Roblox (Luau)

Trang chat giúp viết, giải thích và sửa lỗi script cho **Roblox Studio** (game của chính bạn), dùng mô hình của OpenAI.
Khóa API nằm trên máy chủ (`server.js`), không bao giờ nằm trong trang web.

## Tính năng
- Màn hình chào tự động trước khi vào (lời chào viết sẵn theo buổi, không tốn lượt hỏi).
- Đăng nhập hoặc tạo tài khoản bằng Google (một bước). Người dùng và email được lưu để admin xem.
- Mỗi tài khoản 30 lượt hỏi mỗi ngày, hết thì đợi sang ngày mới (00:00 giờ Việt Nam). Lượt bị lỗi không bị trừ.
- Nút **For admin** ở màn hình đăng nhập. Chỉ email trong `ADMIN_EMAIL` (mặc định abbie129898@gmail.com) vào được. Việc kiểm tra quyền làm ở máy chủ.
- Trang admin: xem danh sách người dùng + email + IP, **cộng/trừ lượt hỏi** cho từng người, **chặn / bỏ chặn IP**, hoặc nhập IP để chặn thủ công.
- Lượt admin tặng được dùng sau khi hết lượt trong ngày và không bị mất khi sang ngày mới.

## Tạo Google Client ID (làm một lần)
1. Vào https://console.cloud.google.com, tạo một project.
2. Mở "APIs & Services" > "OAuth consent screen", chọn External, điền tên ứng dụng và email.
3. Mở "Credentials" > "Create credentials" > "OAuth client ID" > loại **Web application**.
4. Ở "Authorized JavaScript origins" thêm `http://localhost:3000` và địa chỉ trang khi đưa lên mạng (ví dụ `https://ten-cua-ban.onrender.com`).
5. Sao chép Client ID dán vào `GOOGLE_CLIENT_ID` trong `.env`.
Nếu app còn ở chế độ "Testing", chỉ các email bạn thêm vào danh sách "Test users" mới đăng nhập được. Muốn mở cho mọi người, bấm "Publish app".

## Chạy trên máy của bạn
1. Cài Node.js bản 18 trở lên (https://nodejs.org).
2. Lấy khóa API tại https://platform.openai.com/api-keys. Lưu ý: gói ChatGPT Plus/Pro KHÔNG dùng được cho API, API tính tiền riêng.
3. Sao chép `.env.example` thành `.env`, điền `OPENAI_API_KEY` và `GOOGLE_CLIENT_ID`.
4. Chạy `npm start`, mở http://localhost:3000

## Đưa lên mạng
Dùng dịch vụ chạy Node.js (Render, Railway, Fly.io...). Đặt các biến trong `.env` vào Environment Variables, thêm `TRUST_PROXY=1`, không đưa file `.env` lên mạng.
Dữ liệu (người dùng, phiên đăng nhập, IP bị chặn, số lượt) nằm trong thư mục `data/`. Hãy gắn ổ đĩa lưu trữ lâu dài và đặt `DATA_DIR` trỏ vào đó, nếu không mỗi lần triển khai lại dữ liệu sẽ mất.
Đặt thêm hạn mức chi tiêu trong tài khoản OpenAI.

## Lưu ý
- Trang lưu email, tên và IP của người dùng; trang đăng nhập có ghi chú báo điều này. Nếu mở công khai, hãy cân nhắc thêm trang chính sách quyền riêng tư.
- Chặn IP có thể chặn nhầm nhiều người dùng chung một mạng (trường học, 4G). Server không cho admin chặn IP mà chính admin đang hoặc đã dùng.
- Còn một trần lượt theo IP mỗi ngày (mặc định 100, đổi bằng `IP_DAILY_LIMIT`) để khó lách bằng cách tạo nhiều tài khoản.
